DATABASE_CONFIG = {
    'host': 'localhost',
    'user': 'root',          # No specific username
    'password': 'saabu',      # No specific password
    'database': 'onlinedoctor',  # Replace with your actual database name
}
